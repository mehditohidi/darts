Darts
=====

Simple HTML5 darts game made with [Pixi.js](http://www.pixijs.com/). Play it here: https://raulr.github.io/darts.